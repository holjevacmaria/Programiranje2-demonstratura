/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ffos.p2d4;

import javax.swing.JOptionPane;

/**
 *
 * @author Maria
 */
public class Start {
    
    public static void main(String[] args) {
        //Poziv konstruktora bez parametara
        Osoba o = new Osoba();
        //Postavljanje vrijednosti objekta
        o.setIme("Ivana");
        o.setPrezime("Horvat");
        o.setGodine(24);
        o.setStudent(true);
        System.out.println(o.getIme());
        
        //Poziv konstruktora s dva odabrana parametra
        o = new Osoba("Hana","Lelas");
        System.out.println(o.getIme());
        
        //Poziv konstruktora sa svim parametrima
        o = new Osoba("Gaia","Faler",40,true,"Osijek",21000);
        //System.out.println(o.getIme());
        System.out.println(o.getMjesto().getBrojStanovnika());
        
       //Liniji ispod makni komentar da vidiš što će se dogoditi u outputu ako upišeš slovo u input field
       //o.setGodine(Integer.parseInt(JOptionPane.showInputDialog("Unesi godine u obliku cijelog broja")));
       //Unutar try dijela ide kod koji se testira na određeni exception
        try {
            o.setGodine(Integer.parseInt(JOptionPane.showInputDialog("Unesi godine u obliku cijelog broja")));
            System.out.println(o.getGodine());
            // ako dode do exceptiona pod nazivom NumberFormatException, ti ga uhvati i korisniku ispiši poruku - program neće nasilno prestati s radom
        } catch (NumberFormatException e) {
            System.out.println("Niste unjeli cijeli broj");
        }
        
        Dijete d = new Dijete();
        d.setVrtic(true);
        d.setBrojZubi(5);
        d.setIme("Maja");
        d.setPrezime("Majić");
        System.out.println(d.getIme());
        
    }
    
}
