/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ffos.p2d4;

/**
 *
 * @author Maria
 */
//Klasa opisuje objekt
//Klasa se sastoji od svojstava koja su karakteristična objektu
//Naša klasa se zove Osoba, a instanca klase Osoba = pojedini čovjek, ima različite vrijednosti za navedena svojstva 
//Ukratko: Objekt(instanca klase) ima različita vrijednosti za predefinirana svojstva klase.
public class Osoba {
    // 1. KORAK: Privatna svojstva koja su karakteristična objektu
    private String ime;
    private String prezime;
    private int godine;
    private boolean student;
    private Mjesto mjesto;
    
    // 3. KORAK: Konstruktor - posebna metoda klase koje se izvodi u trenutku konstruiranja objekta
    //Konstruiranje objekta se poziva ključnom riječju new
    
        //1. Primjer: Konstruktor koji ne prima parametre
        // desni klik -> insert code -> constructor -> generate

        public Osoba() {
        }
        
        //2. Primjer: Konstruktor koji prima 2 parametra
        // desni klik -> insert code -> constructor -> označiti 2 parametra po želji -> generate

        public Osoba(String ime, String prezime) {
            this.ime = ime;
            this.prezime = prezime;
        }
        
        //3. Primjer: Konstruktor koji prima sve parametre
        // desni klik -> insert code -> constructor -> označiti sve parametre -> generate

        public Osoba(String ime, String prezime, int godine, boolean student, String naziv, int brojStanovnika) {
            this.ime = ime;
            this.prezime = prezime;
            this.godine = godine;
            this.student = student;
            
            mjesto = new Mjesto(naziv, brojStanovnika);
        }
    
    // 2. KORAK: Generiranje gettera i settera
    // desni klik -> insert code -> Getter and Setter -> oznacite sva svojstva na razini klase -> generate
    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public int getGodine() {
        return godine;
    }

    public void setGodine(int godine) {
        this.godine = godine;
    }

    public boolean isStudent() {
        return student;
    }

    public void setStudent(boolean student) {
        this.student = student;
    }
    
    public Mjesto getMjesto() {
        return mjesto;
    }

    public void setMjesto(Mjesto mjesto) {
        this.mjesto = mjesto;
    }
    
}
