/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ffos.p2d4;

/**
 *
 * @author Maria
 */
public class Dijete extends Osoba{
    
    private boolean vrtic;
    private int brojZubi;
    

    public boolean isVrtic() {
        return vrtic;
    }

    public void setVrtic(boolean vrtic) {
        this.vrtic = vrtic;
    }

    public int getBrojZubi() {
        return brojZubi;
    }

    public void setBrojZubi(int brojZubi) {
        this.brojZubi = brojZubi;
    }
    
    
    
    
}
