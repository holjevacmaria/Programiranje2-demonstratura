/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ffos.p2d2;

import java.util.Arrays;

/**
 *
 * @author Maria
 */
public class Vjezba2 {

    public static void main(String[] args) {
        //NIZOVI
        //Zadatak 1.
        //Deklarirajte niz i konstruirajte ga, zatim jednom indeksu pripisite vrijednost
        int niz[];
        niz = new int[5];
        niz[0] = 3;
        System.out.println(Arrays.toString(niz));

        //Zadatak 2.
        //Deklarirajte niz tipa podatka string, konstruirajte ga i dodijelite mu vrijednosti
        String nizRijeci[];
        nizRijeci = new String[3];
        nizRijeci[0] = "Prva riječ";
        nizRijeci[1] = "Druga riječ";
        nizRijeci[2] = "Treća riječ";

        System.out.println(Arrays.toString(nizRijeci));

        //FOR PETLJA
        //Zadatak 1.
        //10 puta ispisi rijec "Demonstratura"
        for (int i = 1; i <= 10; i++) {
            System.out.println("Demonstratura");
        }
        //Zadatak 2.
        //Ispisi sve brojeve od 10 do 1
        for (int j = 10; j > 0; j--) {
            System.out.println(j);
        }
        System.out.println("__________________________");
        //Zadatak 3.
        //Ispisi sve parne brojeve između 1-15
        for (int k = 1; k < 15; k++) {
            if (k % 2 == 0) {
                System.out.println(k);
            }
        }
        System.out.println("__________________________");
        //Zadatak 4.
        //Izvrti petlju koja će preskočiti broj 3
        for (int m = 1; m < 7; m++) {
            if (m == 3) {
                continue;
            }
            System.out.println(m);
        }
        System.out.println("__________________________");
        //Zadatak 5.
        //Izvrtite petlju koja će nasilno prekinuti izvođenje kada dode do broja 3
        for (int n = 1; n < 7; n++) {
            if (n == 3) {
                break;
            }
            System.out.println(n);
        }
        System.out.println("__________________________");
        //FOR EACH PETLJA
        //Zadatak 1.
        //Iterirajte niz uz pomoc for each petlje
        int brojevi[] = {5, 4, 3, 4, 56};
        for (int i = 0; i < brojevi.length; i++) {
            System.out.println(brojevi[i]);
        }
        System.out.println("__________________________");
        for (int i : brojevi) {
            System.out.println(i);
        }

        System.out.println("__________________________");
        //WHILE PETLJA
        //Zadatak 1. 
        //Ispisi sve neparne brojeve od 1 do 10
        int o = 1;
        while (o <= 10) {
            if (o % 2 == 1) {
                System.out.println(o);
            }
            o++;
        }
        System.out.println("__________________________");
        //DO WHILE PETLJA
        //Zadatak 1.
        //Ispisi zbroj prvih 10 brojeva uz pomoc do while petlje
        int prviBroj = 0;
        int drugiBroj = 0;
        do{
            drugiBroj = drugiBroj + prviBroj;
            prviBroj++;
        }while(prviBroj<=10);
        
        System.out.println(drugiBroj);
    }

}
