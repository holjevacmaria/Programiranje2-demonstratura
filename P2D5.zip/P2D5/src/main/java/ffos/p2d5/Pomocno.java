/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ffos.p2d5;

import javax.swing.JOptionPane;

/**
 *
 * @author Maria
 */
public class Pomocno {
    
    public static int ucitajBroj(String poruka) {
        while (true) {
            try {
                return Integer.parseInt(
                        JOptionPane
                                .showInputDialog(poruka)
                );
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Morate unijeti cijeli broj");
            }
        }
    }

    public static String ucitajString(String poruka) { // dodati public
        String s;
        while (true) {
            s = JOptionPane.showInputDialog(poruka);
            if (s.trim().length() == 0) { // trim je metoda koja cisti prazne znakove s lijeve i desne strane
                //ovaj dio osigurava da se korisniku pokaze poruka ako ne unese nikakav podatak ili samo razmake
                JOptionPane.showMessageDialog(null, "Obavezan unos traženog podatka");
                continue;
            }
            return s;
        }

    }

    public static boolean ucitajBoolean(String poruka) {

        while (true) {
            try {
                return Boolean.parseBoolean(
                        JOptionPane.showInputDialog(poruka));

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Neispravan unos, unesite true/false");
            }
        }
    }
    
}
