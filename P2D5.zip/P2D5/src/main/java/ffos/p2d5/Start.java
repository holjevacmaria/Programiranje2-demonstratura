/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ffos.p2d5;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Maria
 */
//PAZITE NA REDOSLIJED KOJIM JE SVE PISANO!
public class Start {

    private List<Ostavljen> ostavljeni; // lista mora biti deklarirana na razini klase
    // nakon List i ArrayList obavezno ctrl+space za import

   
    public Start() {
        //prikaz poruke na početku samog programa
        JOptionPane.showMessageDialog(null, "Dobrodošli u program ostavljenih");
        // ostavljeni = varijabla uz pomoc koje se kreirani entiteti spremaju u listu
        ostavljeni = new ArrayList<>();
        //ova metoda ucitava sve kreirane entitete tipa Ostavljen
        ucitajOstavljeni(); // tu ce pokazat gresku jer ne postoji ta metoda - zarulja - kreiraj metodu
        ispisiAsocijalnost();// isto kreiranje metode uz pomoc zaruljice
    }

    public static void main(String[] args) {
        new Start();
    }
    //ostale metode nisu uključene u psvm jer su već pozvane preko metode start koja se izvodi u psvm

    private void ucitajOstavljeni() {
        // ovo u komentaru ispod je generirano ako metodu napravite uz pomoć žaruljice, to vam ne treba, samo obrišite
        //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.

        // program prekida unos ako korisnik unese slovo h
        String s; //varijabla koja prima podatak o tome želi li korisnik nastaviti ili prekinuti unos
        while (true) {
            ucitajOstavljenog();// sto ce raditi dok ne upis slovo h
            // metoda u redu iznad opet ne postoji.. žaruljica - kreiraj
            //uz pomoc te metode se omogucuje unos pojedinog entiteta
            s = JOptionPane.showInputDialog("Unos slova h za prekid, sve drugo nastavlja unos ostavljenih");
            if (s.toLowerCase().equals("h")) {
                // toLowerCase = ako je korisnik unio H biti ce prikazano h
                // equals = unos vrijednosti nakon koje se prekida unos entiteta
                break;
            }
        }

    }

    //u ovoj metodi se omogućuje dodjeljivanje vrijednosti pojedinim svojstvima od strane korisnika
    private void ucitajOstavljenog() {
        //čisto poruka da korisnik zna što unosi
        JOptionPane.showMessageDialog(null, "Učitajte novog ostavljenog");
        Ostavljen o = new Ostavljen();
        //U klasi pomocno je definirana metoda ucitajBroj koja poziva JOp koji se korisniku prikazuje za unos podatka
        //tamo je i try-catch koji omogućuje ispravnost unosa podataka - da ne dobijemo slova u varijabli koja je int
        o.setSifra(Pomocno.ucitajBroj("Učitaj šifru ostavljenog"));
        o.setMajica(Pomocno.ucitajString("Učitaj najdraži kroj majice"));
        o.setAsocijalno(Pomocno.ucitajBoolean("Da li je asocijalan (unesi true za da, bilo što drugo za false"));
        o.setNeprijatelj(ucitajNeprijatelja());// ovdje opet kreirati metodu uz pomoc zaruljice

        ostavljeni.add(o);// dodaje u listu ostavljeni
    }

    private Neprijatelj ucitajNeprijatelja() {
        //tu će vam na početku pokazivati sintaksu grešku jer nemate return
        JOptionPane.showMessageDialog(null, "Slijedi unos podataka za neprijatelja ostavljenog");
        Neprijatelj n = new Neprijatelj();
        n.setSifra(Pomocno.ucitajBroj("Šifra neprijatelja"));
        n.setGodine(Pomocno.ucitajBroj("Koliko godina ima neprijatelj"));
        n.setSrednjeIme(Pomocno.ucitajString("Koje mu je srednje ime"));
        n.setBojaOciju(Pomocno.ucitajString("Koja mu je boja očiju?"));
        return n;
    }

    private void ispisiAsocijalnost() {// ispisuje vrijednost svojstva asocijalno sa svih instanci..
        for (Ostavljen o : ostavljeni) {
            System.out.println(o.isAsocijalno()); // paziti get i is.. boolean je is, a ne get
        }
    }

}
