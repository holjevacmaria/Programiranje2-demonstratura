/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ffos.zarucnik;

/**
 *
 * @author Maria
 */
public class Zarucnik {
    
    private int sifra;
    private int prsten;
    private float kuna;
    private String materijal;
    private boolean dragiKamen;
    private Ostavljen ostavljen;

    public int getSifra() {
        return sifra;
    }

    public void setSifra(int sifra) {
        this.sifra = sifra;
    }

    public int getPrsten() {
        return prsten;
    }

    public void setPrsten(int prsten) {
        this.prsten = prsten;
    }

    public float getKuna() {
        return kuna;
    }

    public void setKuna(float kuna) {
        this.kuna = kuna;
    }

    public String getMaterijal() {
        return materijal;
    }

    public void setMaterijal(String materijal) {
        this.materijal = materijal;
    }

    public boolean isDragiKamen() {
        return dragiKamen;
    }

    public void setDragiKamen(boolean dragiKamen) {
        this.dragiKamen = dragiKamen;
    }

    public Ostavljen getOstavljen() {
        return ostavljen;
    }

    public void setOstavljen(Ostavljen ostavljen) {
        this.ostavljen = ostavljen;
    }
    
    
  
}
