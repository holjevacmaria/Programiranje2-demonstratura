/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ffos.zarucnik;

/**
 *
 * @author Maria
 */
public class Ostavljen {
    
    private int sifra;
    private int godine;
    private String stilFrizure;
    private boolean asocijalno;
    private boolean introvertno;

    public int getSifra() {
        return sifra;
    }

    public void setSifra(int sifra) {
        this.sifra = sifra;
    }

    public int getGodine() {
        return godine;
    }

    public void setGodine(int godine) {
        this.godine = godine;
    }

    public String getStilFrizure() {
        return stilFrizure;
    }

    public void setStilFrizure(String stilFrizure) {
        this.stilFrizure = stilFrizure;
    }

    public boolean isAsocijalno() {
        return asocijalno;
    }

    public void setAsocijalno(boolean asocijalno) {
        this.asocijalno = asocijalno;
    }

    public boolean isIntrovertno() {
        return introvertno;
    }

    public void setIntrovertno(boolean introvertno) {
        this.introvertno = introvertno;
    }
    
    
}
