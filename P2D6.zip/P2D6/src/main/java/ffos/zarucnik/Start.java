/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ffos.zarucnik;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Maria
 */
public class Start {

    private List<Zarucnik> zarucnici;

    public Start() {
        JOptionPane.showMessageDialog(null, "Dobrodošli u program zaručnika");

        zarucnici = new ArrayList<>();
        ucitajZarucnike();
        ispisiEkstrovertnost();
        ispisiBoolean();

    }

    public static void main(String[] args) {
        new Start();
    }

    private void ucitajZarucnike() {
        String s;
        while (true) {
            ucitajZarucnika();
            s = JOptionPane.showInputDialog("Unosite slovo q za prekid unosa, ostali znakovi nastavljaju unos zaručenih");
            if (s.toLowerCase().equals("q")) {
                break;
            }
        }
    }

    private void ucitajZarucnika() {
        JOptionPane.showMessageDialog(null, "Učitaj novog zaručnika");
        Zarucnik z = new Zarucnik();
        z.setSifra(Pomocno.ucitajBroj("Unesite šifru zaručnika"));
        z.setPrsten(Pomocno.ucitajBroj("Unesite veličinu prstena"));
        z.setKuna(Pomocno.ucitajFloat("Unesite iznos prstena u obliku decimalnog broja"));
        z.setMaterijal(Pomocno.ucitajString("Od koje je materijala prsten?"));
        z.setDragiKamen(Pomocno.ucitajBoolean("Ima li prsten neki dragi kamen? (true/false)"));

        z.setOstavljen(ucitajOstavljen());

        zarucnici.add(z);
    }

    private Ostavljen ucitajOstavljen() {
        // na samom početku baca sintaksu grešku jer nema return koji dode kasnije!
        JOptionPane.showMessageDialog(null, "Učitaj novog ostavljenog");
        Ostavljen o = new Ostavljen();
        o.setSifra(Pomocno.ucitajBroj("Unesi šifru ostavljenog"));
        o.setGodine(Pomocno.ucitajBroj("Koliko godina ima?"));
        o.setStilFrizure(Pomocno.ucitajString("Kakav mu/joj je stil frizure?"));
        o.setAsocijalno(Pomocno.ucitajBoolean("Je li asocijalan/na? (true/false)"));
        o.setIntrovertno(Pomocno.ucitajBoolean("Je li introvertan/na? (true/false)"));
        return o;
    }

    private void ispisiEkstrovertnost() {
        for (Zarucnik z : zarucnici) {
            System.out.println(z.getOstavljen().isAsocijalno());
        }
    }

    private void ispisiBoolean() {

        int s = 0;
        for (Zarucnik z : zarucnici) {
            if (z.getOstavljen().isAsocijalno() == true) {
                s++;
            }
            if (z.getOstavljen().isIntrovertno() == true) {
                s++;
            }
        }

        System.out.println(s);
    }

}
