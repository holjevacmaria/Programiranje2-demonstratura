/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ffos.demonstratura1;

import javax.swing.JOptionPane;

/**
 *
 * @author Maria
 */
public class Vjezba1 {
    
    public static void main(String[] args) {
        
        //Zadatak 1. Učitajte decimalni broj i ispišite ga
        float broj = Float.parseFloat(JOptionPane.showInputDialog("Unesi broj:"));
        System.out.println(broj);
        
        //Zadatak 2. Učitajte riječ i ispišite ju
        String rijec = JOptionPane.showInputDialog("Unesi rijec:");
        System.out.println(rijec);
        
        //Zadatak 3. Korisnik unosi cijeli broj, ako je uneseni broj 7 onda ispisuje SUPER
        int cijeliBroj = Integer.parseInt(JOptionPane.showInputDialog("Unesite cijeli broj:"));
        if(cijeliBroj == 7){
            System.out.println("SUPER");
        }else{
            System.out.println("nije super");
        }
        
        //Zadatak 4. Program za uneseni broj ispisuje njegov kvadrat
        int kvadrat = Integer.parseInt(JOptionPane.showInputDialog("Unesi broj i saznaj njegov kvadrat:"));
        int rezultat = kvadrat*kvadrat;
        System.out.println(rezultat);
        
        //Zadatak 5. Za uneseni broj provjeri da li je paran ili ne
        //int i=9;
        int i = Integer.parseInt(JOptionPane.showInputDialog("Unesi broj i saznaj je li paran ili neparan:"));
        
        if(i%2==0){
            System.out.println("PARAN");
        }else{
            System.out.println("Neparan");
        }

        //Zadatak 6. Korisnik unosi 3 cijela broja, program ispisuje najveći
        int cijeliBroj1 = Integer.parseInt(JOptionPane.showInputDialog("Unesite 1. cijeli broj: "));
        int cijeliBroj2 = Integer.parseInt(JOptionPane.showInputDialog("Unesite 2. cijeli broj: "));
        int cijeliBroj3 = Integer.parseInt(JOptionPane.showInputDialog("Unesite 3. cijeli broj: "));
        
        if(cijeliBroj1 > cijeliBroj2 && cijeliBroj1 > cijeliBroj3){
            System.out.println("Najveci broj je (1.): "+cijeliBroj1);
        }else if(cijeliBroj2 > cijeliBroj3){
            System.out.println("Najveci broj je (2.): "+cijeliBroj2);
        }else{
            System.out.println("Najveci broj je (3.): "+cijeliBroj3);
        }
        
        //Zadatak 7. Kada korisnik upiše broj od 1 do 7, program ispisuje naziv dana u tjednu
        int dan = Integer.parseInt(JOptionPane.showInputDialog("Unesite redni broj dana u tjednu: "));
        
        switch(dan){
            case 1:
                System.out.println("Ponedjeljak");
                break;
            case 2:
                System.out.println("Utorak");
                break;
            case 3:
                System.out.println("Srijeda");
                break;
            case 4:
                System.out.println("Cetvrtak");
                break;
            case 5:
                System.out.println("Petak");
                break;
            case 6:
                System.out.println("Subota");
                break;
            case 7:
                System.out.println("Nedjelja");
                break;
            default:
                System.out.println("Nije dan");
                
        }
        
    }
}
