/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ffos.prijateljice;

import java.util.Date;

/**
 *
 * @author Maria
 */
//klasu koja sadrži drugu klasu kao svojstvo uvijek radite DRUGU
//paziti na boolean - nije GET nego IS
public class Prijateljica {
    private int sifra;
    private float placa;
    private String struka;
    private Date datumRodenja;
    private Neprijateljice neprijateljice;

    public int getSifra() {
        return sifra;
    }

    public void setSifra(int sifra) {
        this.sifra = sifra;
    }

    public float getPlaca() {
        return placa;
    }

    public void setPlaca(float placa) {
        this.placa = placa;
    }

    public String getStruka() {
        return struka;
    }

    public void setStruka(String struka) {
        this.struka = struka;
    }

    public Date getDatumRodenja() {
        return datumRodenja;
    }

    public void setDatumRodenja(Date datumRodenja) {
        this.datumRodenja = datumRodenja;
    }

    public Neprijateljice getNeprijateljice() {
        return neprijateljice;
    }

    public void setNeprijateljice(Neprijateljice neprijateljice) {
        this.neprijateljice = neprijateljice;
    }
    
    

    
}
