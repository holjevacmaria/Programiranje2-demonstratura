/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ffos.prijateljice;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author Maria
 */
public class Start {
// prva stvar u startu - definirati listu NA RAZINI KLASE
    private List<Prijateljica> prijateljice;
//Metoda start koja poziva sve ostale metode
    public Start() {
        //poruka koja obavjestava korisnika da započinje s unosom nakon nje
        JOptionPane.showMessageDialog(null, "Dobrodošli u program Prijateljica");
        //varijabla uz pomoc koje spremamo podatke na listu
        prijateljice = new ArrayList<>();
        //ovdje upišite nazive metoda koje ćete kreirati uz pomoć žaruljice
        //ali samo one metode koje se ne pozivaju kroz druge!!
        //kroz metodu ucitajPrijateljice() se poziva: ucitajPrijateljica(), pa kroz nju ucitajNeprijateljicu()
        ucitajPrijateljice();
        ispisiDatum();
        zbrojZnakova();
        zbrojBrojeva();
        ispisiBoolean();

    }
//psvm koji pokreće metodu start koja pokreće sve druge metode
    public static void main(String[] args) {
        new Start();
    }
//Ovo je input field koji se pokaže korisniku na kraju unosa podataka za sva svojstva
// Daje korisniku izbor da nastavi s unosom ili prekine
    private void ucitajPrijateljice() {
        String s;
        while (true) {
            ucitajPrijateljica();
            s = JOptionPane.showInputDialog("Unosite slovo r za prekid unosa, ostali znakovi nastavljaju unos zaručenih");
            //za promjenu slova koje prekida unos, promijeni slovo unutar metode equals
            if (s.toLowerCase().equals("r")) {
                break;
            }
        }
    }
//Omogućuje korisniku unos podataka za svojstva klase
    private void ucitajPrijateljica() {
        //Poruka da kreće unos Prijateljice
        JOptionPane.showMessageDialog(null, "Unos Prijateljica");
        // Kreiramo prazan konstruktor za objekt prijateljica i omogucujemo korisniku unos podataka za zadana svojstva
        Prijateljica p = new Prijateljica();
        p.setSifra(Pomocno.ucitajBroj("Unesi sifru"));
        p.setPlaca(Pomocno.ucitajFloat("Unesi placu"));
        p.setStruka(Pomocno.ucitajString("Unesi struku"));
        p.setDatumRodenja(Pomocno.ucitajDate("Upiši datum rođenja dd.MM.yyyy."));
        //Posto je neprijateljica klasa koja ima svoja svojstva - umjesto pomocno.. radimo metodu za učitavanje svojstava te klase
        //ovdje uz pomoc zaruljice generirajte tu metodu
        p.setNeprijateljice(ucitajNeprijateljicu());
        //NE ZABORAVITI DODATI SVE PODATKE U LISTU!
        prijateljice.add(p);
        //!!!!!!!!!!!!!!!!!!!!!!!!!!!

    }
//sve isto kao i za prijateljicu
//OBAVEZAN RETURN STATEMENT - prikazivat ce gresku dok ga ne stavite
    private Neprijateljice ucitajNeprijateljicu() {
        JOptionPane.showMessageDialog(null, "Unos Neprijateljica");
        Neprijateljice n = new Neprijateljice();
        n.setSifra(Pomocno.ucitajBroj("Ucitaj sifru n"));
        n.setIntrovertna(Pomocno.ucitajBoolean("Introvertna"));
        n.setAsocijalan(Pomocno.ucitajBoolean("Asocijalna"));
        n.setRazlog(Pomocno.ucitajString("Učitaj razlog neprijateljstva"));
        n.setDatum(Pomocno.ucitajDate("Od kad ste neprijateljice"));
        return n;
    }
//uz pomoc foreach petlje ispisujemo vrijednost na zadanom svojstvu
    private void ispisiDatum() {
        for (Prijateljica p : prijateljice) {
            System.out.println(p.getNeprijateljice().getDatum());
        }
    }
//zbrajanje svih unesenih znakova na određenom svojstvu
    private void zbrojZnakova() {
        
        int d = 0;
        for (Prijateljica p : prijateljice) {
            //d+= ostatak - isto što i d= d+ostatak - to omogućuje da zbraja pri svakom unosu
            // trim metoda brise s lijeve i desne strane sve razmake, metoda length vraća brojčanu vrijednost dužine stringa
            d += p.getNeprijateljice().getRazlog().trim().length();
        }
        //izvan foreach petlje
        System.out.println("Zbroj svih znakova u varijabli razlog je: "+ d);
        
    }
//zbrajanje svih unesenih brojeva na određenom svojstvu
    private void zbrojBrojeva() {
        int suma = 0;
        for (Prijateljica p : prijateljice) {
            suma += p.getNeprijateljice().getSifra() + p.getSifra();
        }
        //izvan foreach petlje
        System.out.println("Suma svih unesenih cijelih brojeva je: " + suma);
    }
//broji koliko je true vrijednosti uneseno 
    private void ispisiBoolean() {
        // pomocna varijabla koja sluzi za iteriranje
        int b = 0;
        for (Prijateljica p : prijateljice) {
            //ako je vrijednost na ovom svojstvu == true, povećaj našu varijablu za 1 cijeli broj
            if (p.getNeprijateljice().isIntrovertna() == true) {
                b++;
            }
            if (p.getNeprijateljice().isAsocijalan() == true) {
                b++;
            }
        }
        //izvan foreach petlje
        System.out.println("Zboj true logičkih tipova pod na nep: " + b);
    }

}
