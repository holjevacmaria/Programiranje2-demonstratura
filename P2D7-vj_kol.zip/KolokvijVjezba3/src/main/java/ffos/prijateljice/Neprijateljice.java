/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ffos.prijateljice;

import java.util.Date;

/**
 *
 * @author Maria
 */
//Klasu koja je jednostavnija, odnosno koja nema drugu klasu kao svojstvo, radite PRVU!
//paziti na boolean - nije GET nego IS
public class Neprijateljice {
    private int sifra; 
    private boolean introvertna;
    private boolean asocijalan;
    private String razlog;
    private Date datum;

    public int getSifra() {
        return sifra;
    }

    public void setSifra(int sifra) {
        this.sifra = sifra;
    }

    public boolean isIntrovertna() {
        return introvertna;
    }

    public void setIntrovertna(boolean introvertna) {
        this.introvertna = introvertna;
    }

    public boolean isAsocijalan() {
        return asocijalan;
    }

    public void setAsocijalan(boolean asocijalan) {
        this.asocijalan = asocijalan;
    }

    public String getRazlog() {
        return razlog;
    }

    public void setRazlog(String razlog) {
        this.razlog = razlog;
    }

    public Date getDatum() {
        return datum;
    }

    public void setDatum(Date datum) {
        this.datum = datum;
    }
    

}
