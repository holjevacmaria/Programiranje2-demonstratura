/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ffos.d3;

import javax.swing.JOptionPane;

/**
 *
 * @author Maria
 */
public class Vjezba {

    public static void main(String[] args) {

        //Zadatak 1. 
        //Ispišite brojeve od 100 do 1, jedno pored drugoga - FOR PETLJA
        for (int i = 100; i > 0; i--) {
            System.out.print(i + " ");

        }

        //Zadatak 2.
        //Ispišite brojeve od 100 do 1, jedno pored drugoga - WHILE PETLJA
        int j = 101;
        while (true) {
            j--;
            if (j < 1) {
                break;
            }
            System.out.print(j + " ");
        }

        //Zadatak 3.
        //Za tri primljena broja (npr. 3,7,4) ispisati najveći
        int broj1 = Integer.parseInt(JOptionPane.showInputDialog("Unesite 1. cijeli broj: "));
        int broj2 = Integer.parseInt(JOptionPane.showInputDialog("Unesite 2. cijeli broj: "));
        int broj3 = Integer.parseInt(JOptionPane.showInputDialog("Unesite 3. cijeli broj: "));

        if (broj1 > broj2 && broj1 > broj3) {
            System.out.println("Najveci broj je (1.): " + broj1);
        } else if (broj2 > broj3) {
            System.out.println("Najveci broj je (2.): " + broj2);
        } else {
            System.out.println("Najveci broj je (3.): " + broj3);
        }

        //Zadatak 4.
        //Trazite od korisnika broj sve dok ne unese broj 1 - FOR PETLJA
        int drugiBroj;
        for (;;) {
            drugiBroj = Integer.parseInt(JOptionPane.showInputDialog("Upisi broj, samo jedan te vodi van iz petlje"));
            if (drugiBroj == 1) {
                break;
            }
            System.out.println("Probaj ponovo.. samo JEDAN broj");
        }
        System.out.println("Bravo!");

        //Zadatak 5.
        //Trazite od korisnika broj sve dok ne unese broj 1 - WHILE PETLJA
        int broj;
        while (true) {
            broj = Integer.parseInt(JOptionPane.showInputDialog("Upisi broj, samo jedan te vodi van iz petlje"));
            if (broj == 1) {
                break;
            }
            System.out.println("Probaj ponovo.. samo JEDAN broj");
        }
        System.out.println("Bravo!");

        //Zadatak 6. 
        //Korisnik unosi cijele brojeve sve dok se ne unese broj 0. Program ispisuje sumu svih unesenih brojeva
        int zbrajanje = 0;
        int brojKorisnika;

        while (true) {
            brojKorisnika = Integer.parseInt(JOptionPane.showInputDialog("Dok ne uneses broj 0, uneseni brojevi se zbrajaju"));
            if (brojKorisnika != 0) {
                zbrajanje = zbrajanje + brojKorisnika;
            }else{
                break;
            }
        }
        System.out.println(zbrajanje);
        
        //Zadatak 7.
        //Za dani broj provjerite da li je prosti (prim) broj
        
        //ispod je zakomentirano kada korisnik unosi, ali brze vam je da u varijabli sami mjenjate broj 
        //int uneseniBroj = Integer.parseInt(JOptionPane.showInputDialog("Unesi broj i provjeri je li prim broj"));
        int uneseniBroj = 3;
        boolean trueFalse = false;
        //određuje se koji je najveći cjeloviti djelitelj broja - npr. od 100 je 50 jer 100/2=50 (uneseniBroj/2)
        //svi cjeloviti djelitelji cjelih brojeva su manji ili jednaki broj/2!
        //++i = prvo uvecavamo varijablu i pa onda provjeravamo djeljivost sa brojem do njegovog najveceg cjelovitog djelitelja
        for (int i = 2; i <= uneseniBroj / 2; ++i) {
            // ovdje se provjerava je li broj djeljiv bez ostatka
            if (uneseniBroj % i == 0) {
                trueFalse = true;
                break;
            }
        }
        //ako varijabla trueFalse nema vrijednost false - onda je prim broj
        if (!trueFalse) {
            System.out.println(uneseniBroj + " - > ovaj broj je prim broj");
        // else - odnosno ako varijabl trueFalse ima vrijednost false - onda nije prim broj
        } else {
            System.out.println(uneseniBroj + "- > ovaj broj nije prim broj");
        }

    }

}
